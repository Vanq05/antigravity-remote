import 'package:antigravity_remote/data/repositories/session_repository.dart';
import 'package:antigravity_remote/data/services/local_storage_service.dart';
import 'package:antigravity_remote/main.dart';
import 'package:antigravity_remote/ui/features/home/view_models/home_view_model.dart';
import 'package:flutter_test/flutter_test.dart';

class _FakeStorageService extends LocalStorageService {
  @override
  Future<String?> readSessionsJson() async => null;

  @override
  Future<void> writeSessionsJson(String jsonString) async {}
}

void main() {
  testWidgets('renders Antigravity Remote home screen', (tester) async {
    final repository = SessionRepository(
      storageService: _FakeStorageService(),
    );
    final viewModel = HomeViewModel(sessionRepository: repository);

    await tester.pumpWidget(
      AntigravityRemoteApp(
        homeViewModel: viewModel,
        sessionRepository: repository,
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('Antigravity Remote'), findsOneWidget);
    expect(find.text('Quét mã QR Remote Control'), findsOneWidget);
  });
}

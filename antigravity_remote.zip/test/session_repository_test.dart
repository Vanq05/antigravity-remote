import 'package:antigravity_remote/data/repositories/session_repository.dart';
import 'package:antigravity_remote/data/services/local_storage_service.dart';
import 'package:flutter_test/flutter_test.dart';

class _InMemoryStorageService extends LocalStorageService {
  String? _data;

  @override
  Future<String?> readSessionsJson() async => _data;

  @override
  Future<void> writeSessionsJson(String jsonString) async {
    _data = jsonString;
  }
}

void main() {
  late _InMemoryStorageService storage;
  late SessionRepository repository;

  setUp(() {
    storage = _InMemoryStorageService();
    repository = SessionRepository(storageService: storage);
  });

  group('SessionRepository.normalizeRemoteUrl', () {
    test('accepts standard https remote link', () {
      expect(
        repository.normalizeRemoteUrl('https://antigravity.google/remote/abc'),
        'https://antigravity.google/remote/abc',
      );
    });

    test('prepends https for bare domain and http for local LAN IP', () {
      expect(
        repository.normalizeRemoteUrl('antigravity.google/r/123'),
        'https://antigravity.google/r/123',
      );
      expect(
        repository.normalizeRemoteUrl('192.168.1.50:8080'),
        'http://192.168.1.50:8080',
      );
    });

    test('extracts url from JSON QR payload', () {
      expect(
        repository.normalizeRemoteUrl(
          '{"url":"https://antigravity.google/remote/token123"}',
        ),
        'https://antigravity.google/remote/token123',
      );
    });

    test('returns null for invalid inputs', () {
      expect(repository.normalizeRemoteUrl(''), isNull);
      expect(repository.normalizeRemoteUrl('not a valid url :::'), isNull);
    });
  });

  group('SessionRepository persistence', () {
    test('saves, pins, renames, and deletes sessions', () async {
      var list = await repository.saveOrUpdateSession(
        rawUrl: 'https://antigravity.google/remote/1',
        customName: 'PC Home',
      );
      expect(list.length, 1);
      expect(list.first.name, 'PC Home');

      list = await repository.saveOrUpdateSession(
        rawUrl: 'https://antigravity.google/remote/2',
        customName: 'PC Office',
      );
      expect(list.length, 2);

      // Pin first session so it moves to the top
      final homeId = list.firstWhere((s) => s.name == 'PC Home').id;
      list = await repository.togglePin(homeId);
      expect(list.first.id, homeId);
      expect(list.first.isPinned, isTrue);

      // Rename
      list = await repository.renameSession(homeId, 'Workstation');
      expect(list.first.name, 'Workstation');

      // Delete
      list = await repository.deleteSession(homeId);
      expect(list.length, 1);
      expect(list.first.name, 'PC Office');
    });
  });
}

import 'dart:convert';

import '../../domain/models/remote_session.dart';
import '../services/local_storage_service.dart';

/// Repository responsible for managing saved Remote Control sessions
/// and normalizing/validating incoming Remote Control links or QR payloads.
class SessionRepository {
  SessionRepository({required LocalStorageService storageService})
      : _storageService = storageService;

  final LocalStorageService _storageService;

  static const String defaultRemotePortalUrl = 'https://antigravity.google';

  /// Extracts and normalizes a valid HTTP/HTTPS URL from raw user input or QR payload.
  /// Returns null if the input cannot be parsed into a valid web URL.
  String? normalizeRemoteUrl(String rawInput) {
    var candidate = rawInput.trim();
    if (candidate.isEmpty) return null;

    // Support QR payloads wrapped in JSON (e.g. {"url": "https://..."}).
    if (candidate.startsWith('{') && candidate.endsWith('}')) {
      try {
        final decoded = jsonDecode(candidate);
        if (decoded is Map<String, dynamic>) {
          final extracted =
              decoded['url'] ?? decoded['remoteUrl'] ?? decoded['link'];
          if (extracted is String && extracted.trim().isNotEmpty) {
            candidate = extracted.trim();
          }
        }
      } catch (_) {
        // Fall through to standard URL parsing.
      }
    }

    // If user pasted a URL without a scheme, infer http for local addresses or https otherwise.
    if (!candidate.contains('://')) {
      final isLocal = candidate.startsWith('localhost') ||
          candidate.startsWith('127.') ||
          candidate.startsWith('192.168.') ||
          candidate.startsWith('10.') ||
          RegExp(r'^172\.(1[6-9]|2\d|3[0-1])\.').hasMatch(candidate);
      candidate = '${isLocal ? 'http' : 'https'}://$candidate';
    }

    final uri = Uri.tryParse(candidate);
    if (uri == null ||
        !uri.hasScheme ||
        (uri.scheme != 'http' && uri.scheme != 'https') ||
        uri.host.isEmpty) {
      return null;
    }

    return uri.toString();
  }

  /// Generates a human-friendly default display name from a Remote Control URL.
  String deriveSessionName(String normalizedUrl) {
    final uri = Uri.tryParse(normalizedUrl);
    if (uri == null) return 'Antigravity Remote';

    if (uri.host.contains('antigravity.google')) {
      return 'Antigravity Remote';
    }
    if (uri.hasPort) {
      return '${uri.host}:${uri.port}';
    }
    return uri.host;
  }

  Future<List<RemoteSession>> loadSessions() async {
    final rawJson = await _storageService.readSessionsJson();
    if (rawJson == null || rawJson.isEmpty) {
      return const <RemoteSession>[];
    }

    try {
      final decoded = jsonDecode(rawJson) as List<dynamic>;
      final sessions = decoded
          .whereType<Map<String, dynamic>>()
          .map(RemoteSession.fromJson)
          .toList();
      return _sortSessions(sessions);
    } catch (_) {
      return const <RemoteSession>[];
    }
  }

  Future<List<RemoteSession>> saveOrUpdateSession({
    required String rawUrl,
    String? customName,
    bool preferDesktopMode = true,
  }) async {
    final normalized = normalizeRemoteUrl(rawUrl);
    if (normalized == null) {
      throw const FormatException('Đường dẫn Remote Control không hợp lệ.');
    }

    final existing = await loadSessions();
    final now = DateTime.now();
    final existingIndex = existing.indexWhere((s) => s.url == normalized);

    final updated = List<RemoteSession>.from(existing);
    if (existingIndex >= 0) {
      final current = updated[existingIndex];
      updated[existingIndex] = current.copyWith(
        name: (customName != null && customName.trim().isNotEmpty)
            ? customName.trim()
            : current.name,
        lastUsedAt: now,
        preferDesktopMode: preferDesktopMode,
      );
    } else {
      updated.add(
        RemoteSession(
          id: now.microsecondsSinceEpoch.toString(),
          name: (customName != null && customName.trim().isNotEmpty)
              ? customName.trim()
              : deriveSessionName(normalized),
          url: normalized,
          lastUsedAt: now,
          preferDesktopMode: preferDesktopMode,
        ),
      );
    }

    final sorted = _sortSessions(updated);
    await _persist(sorted);
    return sorted;
  }

  Future<List<RemoteSession>> togglePin(String id) async {
    final existing = await loadSessions();
    final updated = existing.map((session) {
      if (session.id == id) {
        return session.copyWith(isPinned: !session.isPinned);
      }
      return session;
    }).toList();

    final sorted = _sortSessions(updated);
    await _persist(sorted);
    return sorted;
  }

  Future<List<RemoteSession>> renameSession(String id, String newName) async {
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return loadSessions();

    final existing = await loadSessions();
    final updated = existing.map((session) {
      if (session.id == id) {
        return session.copyWith(name: trimmed);
      }
      return session;
    }).toList();

    final sorted = _sortSessions(updated);
    await _persist(sorted);
    return sorted;
  }

  Future<List<RemoteSession>> updateDesktopMode(
    String id,
    bool preferDesktopMode,
  ) async {
    final existing = await loadSessions();
    final updated = existing.map((session) {
      if (session.id == id) {
        return session.copyWith(preferDesktopMode: preferDesktopMode);
      }
      return session;
    }).toList();

    final sorted = _sortSessions(updated);
    await _persist(sorted);
    return sorted;
  }

  Future<List<RemoteSession>> deleteSession(String id) async {
    final existing = await loadSessions();
    final updated = existing.where((s) => s.id != id).toList();
    final sorted = _sortSessions(updated);
    await _persist(sorted);
    return sorted;
  }

  List<RemoteSession> _sortSessions(List<RemoteSession> list) {
    final copy = List<RemoteSession>.from(list);
    copy.sort((a, b) {
      if (a.isPinned != b.isPinned) {
        return a.isPinned ? -1 : 1;
      }
      return b.lastUsedAt.compareTo(a.lastUsedAt);
    });
    return copy;
  }

  Future<void> _persist(List<RemoteSession> sessions) async {
    final encoded = jsonEncode(sessions.map((s) => s.toJson()).toList());
    await _storageService.writeSessionsJson(encoded);
  }
}

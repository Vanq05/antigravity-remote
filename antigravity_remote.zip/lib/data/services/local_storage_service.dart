import 'package:shared_preferences/shared_preferences.dart';

/// Stateless persistence service wrapping SharedPreferences.
class LocalStorageService {
  const LocalStorageService();

  static const String _sessionsKey = 'antigravity_remote_sessions_v1';

  Future<String?> readSessionsJson() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_sessionsKey);
  }

  Future<void> writeSessionsJson(String jsonString) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_sessionsKey, jsonString);
  }
}

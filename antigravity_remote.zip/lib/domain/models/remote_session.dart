import 'package:flutter/foundation.dart';

/// Immutable domain model representing a saved Antigravity Remote Control session.
@immutable
class RemoteSession {
  const RemoteSession({
    required this.id,
    required this.name,
    required this.url,
    required this.lastUsedAt,
    this.isPinned = false,
    this.preferDesktopMode = true,
  });

  final String id;
  final String name;
  final String url;
  final DateTime lastUsedAt;
  final bool isPinned;
  final bool preferDesktopMode;

  RemoteSession copyWith({
    String? id,
    String? name,
    String? url,
    DateTime? lastUsedAt,
    bool? isPinned,
    bool? preferDesktopMode,
  }) {
    return RemoteSession(
      id: id ?? this.id,
      name: name ?? this.name,
      url: url ?? this.url,
      lastUsedAt: lastUsedAt ?? this.lastUsedAt,
      isPinned: isPinned ?? this.isPinned,
      preferDesktopMode: preferDesktopMode ?? this.preferDesktopMode,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      'url': url,
      'lastUsedAt': lastUsedAt.toIso8601String(),
      'isPinned': isPinned,
      'preferDesktopMode': preferDesktopMode,
    };
  }

  factory RemoteSession.fromJson(Map<String, dynamic> json) {
    return RemoteSession(
      id: json['id'] as String,
      name: json['name'] as String,
      url: json['url'] as String,
      lastUsedAt: DateTime.parse(json['lastUsedAt'] as String),
      isPinned: json['isPinned'] as bool? ?? false,
      preferDesktopMode: json['preferDesktopMode'] as bool? ?? true,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is RemoteSession &&
        other.id == id &&
        other.name == name &&
        other.url == url &&
        other.lastUsedAt == lastUsedAt &&
        other.isPinned == isPinned &&
        other.preferDesktopMode == preferDesktopMode;
  }

  @override
  int get hashCode => Object.hash(
        id,
        name,
        url,
        lastUsedAt,
        isPinned,
        preferDesktopMode,
      );
}

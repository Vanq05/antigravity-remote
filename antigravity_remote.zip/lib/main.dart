import 'package:flutter/material.dart';

import 'data/repositories/session_repository.dart';
import 'data/services/local_storage_service.dart';
import 'ui/core/theme/app_theme.dart';
import 'ui/features/home/view_models/home_view_model.dart';
import 'ui/features/home/views/home_view.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  const storageService = LocalStorageService();
  final sessionRepository = SessionRepository(storageService: storageService);
  final homeViewModel = HomeViewModel(sessionRepository: sessionRepository);

  runApp(
    AntigravityRemoteApp(
      homeViewModel: homeViewModel,
      sessionRepository: sessionRepository,
    ),
  );
}

class AntigravityRemoteApp extends StatelessWidget {
  const AntigravityRemoteApp({
    super.key,
    required this.homeViewModel,
    required this.sessionRepository,
  });

  final HomeViewModel homeViewModel;
  final SessionRepository sessionRepository;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Antigravity Remote',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: HomeView(
        viewModel: homeViewModel,
        sessionRepository: sessionRepository,
      ),
    );
  }
}

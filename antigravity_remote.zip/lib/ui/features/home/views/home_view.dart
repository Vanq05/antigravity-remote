import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../../data/repositories/session_repository.dart';
import '../../../../domain/models/remote_session.dart';
import '../../remote_workspace/views/remote_workspace_view.dart';
import '../../scanner/views/qr_scanner_view.dart';
import '../view_models/home_view_model.dart';

/// Home screen for connecting to Antigravity Remote Control via QR code,
/// manual link entry, or saved sessions.
class HomeView extends StatefulWidget {
  const HomeView({
    super.key,
    required this.viewModel,
    required this.sessionRepository,
  });

  final HomeViewModel viewModel;
  final SessionRepository sessionRepository;

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  final TextEditingController _urlController = TextEditingController();
  bool _preferDesktopMode = true;

  @override
  void initState() {
    super.initState();
    widget.viewModel.loadSessions();
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _openScanner() async {
    final scanned = await Navigator.of(context).push<String>(
      MaterialPageRoute<String>(
        builder: (_) => const QrScannerView(),
      ),
    );

    if (scanned == null || scanned.trim().isEmpty || !mounted) return;

    _urlController.text = scanned;
    await _connect(scanned);
  }

  Future<void> _pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim();
    if (text != null && text.isNotEmpty) {
      _urlController.text = text;
      widget.viewModel.clearError();
    }
  }

  Future<void> _connect(String rawUrl) async {
    FocusScope.of(context).unfocus();
    final session = await widget.viewModel.connectToUrl(
      rawUrl,
      preferDesktopMode: _preferDesktopMode,
    );
    if (session == null || !mounted) return;
    await _openSession(session);
  }

  Future<void> _openSession(RemoteSession session) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => RemoteWorkspaceView(
          session: session,
          sessionRepository: widget.sessionRepository,
        ),
      ),
    );
    if (mounted) {
      await widget.viewModel.loadSessions();
    }
  }

  Future<void> _showRenameDialog(RemoteSession session) async {
    final controller = TextEditingController(text: session.name);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Đổi tên phiên'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Ví dụ: PC Công ty, Laptop Cá nhân...',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Hủy'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(controller.text),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
    controller.dispose();

    if (result != null && result.trim().isNotEmpty) {
      await widget.viewModel.renameSession(session.id, result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: theme.colorScheme.primary.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.rocket_launch_rounded,
                size: 18,
                color: theme.colorScheme.primary,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Antigravity Remote',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
      body: ListenableBuilder(
        listenable: widget.viewModel,
        builder: (context, _) {
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            children: [
              // Primary QR Scan Hero Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Kết nối máy tính từ xa',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Bật Remote Control trên Antigravity Desktop (Ctrl+Shift+R) rồi quét mã QR hoặc dán link để điều khiển đầy đủ như trên máy tính.',
                        style: TextStyle(
                          fontSize: 13.5,
                          color: theme.colorScheme.onSurface
                              .withValues(alpha: 0.72),
                        ),
                      ),
                      const SizedBox(height: 18),
                      FilledButton.icon(
                        onPressed: _openScanner,
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: const Icon(Icons.qr_code_scanner_rounded),
                        label: const Text(
                          'Quét mã QR Remote Control',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Manual URL Input Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text(
                        'Hoặc nhập link Remote Control',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _urlController,
                        keyboardType: TextInputType.url,
                        textInputAction: TextInputAction.go,
                        autocorrect: false,
                        onChanged: (_) => widget.viewModel.clearError(),
                        onSubmitted: _connect,
                        decoration: InputDecoration(
                          hintText: 'https://antigravity.google/...',
                          prefixIcon: const Icon(Icons.link_rounded),
                          suffixIcon: IconButton(
                            tooltip: 'Dán từ bộ nhớ tạm',
                            icon: const Icon(Icons.content_paste_rounded),
                            onPressed: _pasteFromClipboard,
                          ),
                          errorText: widget.viewModel.errorMessage,
                        ),
                      ),
                      const SizedBox(height: 10),
                      SwitchListTile.adaptive(
                        contentPadding: EdgeInsets.zero,
                        title: const Text(
                          'Chế độ Desktop đầy đủ',
                          style: TextStyle(fontSize: 14),
                        ),
                        subtitle: const Text(
                          'Hiển thị đầy đủ sidebar, chat canvas, terminal và artifacts',
                          style: TextStyle(fontSize: 12),
                        ),
                        value: _preferDesktopMode,
                        onChanged: (value) {
                          setState(() {
                            _preferDesktopMode = value;
                          });
                        },
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.tonalIcon(
                              onPressed: () => _connect(_urlController.text),
                              icon: const Icon(Icons.login_rounded),
                              label: const Text('Kết nối'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          OutlinedButton.icon(
                            onPressed: () => _connect(
                              SessionRepository.defaultRemotePortalUrl,
                            ),
                            icon: const Icon(Icons.public_rounded, size: 18),
                            label: const Text('Portal'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Saved / Recent Sessions
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Phiên gần đây',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  if (widget.viewModel.sessions.isNotEmpty)
                    Text(
                      '${widget.viewModel.sessions.length} phiên',
                      style: TextStyle(
                        fontSize: 12.5,
                        color: theme.colorScheme.onSurface
                            .withValues(alpha: 0.6),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              if (widget.viewModel.isLoading)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (widget.viewModel.sessions.isEmpty)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        Icon(
                          Icons.devices_other_rounded,
                          size: 36,
                          color: theme.colorScheme.onSurface
                              .withValues(alpha: 0.4),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'Chưa có phiên nào được lưu',
                          style: TextStyle(
                            color: theme.colorScheme.onSurface
                                .withValues(alpha: 0.7),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              else
                ...widget.viewModel.sessions.map(
                  (session) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _SessionCard(
                      session: session,
                      onTap: () => _openSession(session),
                      onTogglePin: () => widget.viewModel.togglePin(session.id),
                      onRename: () => _showRenameDialog(session),
                      onDelete: () =>
                          widget.viewModel.deleteSession(session.id),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _SessionCard extends StatelessWidget {
  const _SessionCard({
    required this.session,
    required this.onTap,
    required this.onTogglePin,
    required this.onRename,
    required this.onDelete,
  });

  final RemoteSession session;
  final VoidCallback onTap;
  final VoidCallback onTogglePin;
  final VoidCallback onRename;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: CircleAvatar(
          backgroundColor: session.isPinned
              ? theme.colorScheme.primary.withValues(alpha: 0.22)
              : theme.colorScheme.surfaceContainerHighest,
          child: Icon(
            session.isPinned ? Icons.push_pin_rounded : Icons.computer_rounded,
            size: 19,
            color: session.isPinned
                ? theme.colorScheme.primary
                : theme.colorScheme.onSurface,
          ),
        ),
        title: Text(
          session.name,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          session.url,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 12,
            color: theme.colorScheme.onSurface.withValues(alpha: 0.65),
          ),
        ),
        onTap: onTap,
        trailing: PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'pin':
                onTogglePin();
              case 'rename':
                onRename();
              case 'delete':
                onDelete();
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem<String>(
              value: 'pin',
              child: Text(session.isPinned ? 'Bỏ ghim' : 'Ghim lên đầu'),
            ),
            const PopupMenuItem<String>(
              value: 'rename',
              child: Text('Đổi tên'),
            ),
            const PopupMenuItem<String>(
              value: 'delete',
              child: Text('Xóa'),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/foundation.dart';

import '../../../../data/repositories/session_repository.dart';
import '../../../../domain/models/remote_session.dart';

/// ViewModel managing the Home screen state:
/// saved/recent Remote Control sessions, URL validation, and session actions.
class HomeViewModel extends ChangeNotifier {
  HomeViewModel({required SessionRepository sessionRepository})
      : _sessionRepository = sessionRepository;

  final SessionRepository _sessionRepository;

  List<RemoteSession> _sessions = const <RemoteSession>[];
  List<RemoteSession> get sessions => List.unmodifiable(_sessions);

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  Future<void> loadSessions() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _sessions = await _sessionRepository.loadSessions();
    } catch (_) {
      _errorMessage = 'Không thể tải danh sách phiên đã lưu.';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Validates, saves, and returns the [RemoteSession] to open.
  /// Returns null and sets [errorMessage] if the URL is invalid.
  Future<RemoteSession?> connectToUrl(
    String rawUrl, {
    String? customName,
    bool preferDesktopMode = true,
  }) async {
    _errorMessage = null;
    final normalized = _sessionRepository.normalizeRemoteUrl(rawUrl);
    if (normalized == null) {
      _errorMessage =
          'Link không hợp lệ. Hãy nhập hoặc quét đúng link Remote Control (ví dụ: https://antigravity.google/...).';
      notifyListeners();
      return null;
    }

    _sessions = await _sessionRepository.saveOrUpdateSession(
      rawUrl: normalized,
      customName: customName,
      preferDesktopMode: preferDesktopMode,
    );
    notifyListeners();

    return _sessions.firstWhere((s) => s.url == normalized);
  }

  Future<void> togglePin(String id) async {
    _sessions = await _sessionRepository.togglePin(id);
    notifyListeners();
  }

  Future<void> renameSession(String id, String newName) async {
    _sessions = await _sessionRepository.renameSession(id, newName);
    notifyListeners();
  }

  Future<void> deleteSession(String id) async {
    _sessions = await _sessionRepository.deleteSession(id);
    notifyListeners();
  }

  void clearError() {
    if (_errorMessage != null) {
      _errorMessage = null;
      notifyListeners();
    }
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../../data/repositories/session_repository.dart';
import '../../../../domain/models/remote_session.dart';
import '../view_models/remote_workspace_view_model.dart';

/// Full-featured remote workspace screen hosting Antigravity Remote Control
/// inside a native WKWebView with Desktop/Mobile mode switching and fullscreen controls.
class RemoteWorkspaceView extends StatefulWidget {
  const RemoteWorkspaceView({
    super.key,
    required this.session,
    required this.sessionRepository,
  });

  final RemoteSession session;
  final SessionRepository sessionRepository;

  @override
  State<RemoteWorkspaceView> createState() => _RemoteWorkspaceViewState();
}

class _RemoteWorkspaceViewState extends State<RemoteWorkspaceView> {
  late final RemoteWorkspaceViewModel _viewModel;
  late final WebViewController _webViewController;

  @override
  void initState() {
    super.initState();
    _viewModel = RemoteWorkspaceViewModel(
      session: widget.session,
      sessionRepository: widget.sessionRepository,
    );

    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0D1117))
      ..setUserAgent(_viewModel.activeUserAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            _viewModel.updateProgress(progress);
          },
          onPageStarted: (String url) {
            _viewModel.setLoadError(null);
            _viewModel.updateNavigationState(url: url);
          },
          onPageFinished: (String url) async {
            final title = await _webViewController.getTitle();
            final canGoBack = await _webViewController.canGoBack();
            final canGoForward = await _webViewController.canGoForward();
            _viewModel.updateProgress(100);
            _viewModel.updateNavigationState(
              url: url,
              title: title,
              canGoBack: canGoBack,
              canGoForward: canGoForward,
            );
          },
          onWebResourceError: (WebResourceError error) {
            if (error.isForMainFrame ?? true) {
              _viewModel.setLoadError(
                'Không thể kết nối tới phiên Remote Control (${error.description}).',
              );
            }
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.session.url));
  }

  @override
  void dispose() {
    _viewModel.dispose();
    super.dispose();
  }

  Future<void> _toggleDesktopMode() async {
    await _viewModel.toggleDesktopMode();
    await _webViewController.setUserAgent(_viewModel.activeUserAgent);
    await _webViewController.reload();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _viewModel.isDesktopMode
              ? 'Đã chuyển sang chế độ Desktop đầy đủ'
              : 'Đã chuyển sang chế độ Mobile gọn nhẹ',
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _copyCurrentUrl() async {
    await Clipboard.setData(ClipboardData(text: _viewModel.currentUrl));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Đã sao chép link Remote Control'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Future<void> _openInExternalBrowser() async {
    final uri = Uri.tryParse(_viewModel.currentUrl);
    if (uri != null) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _viewModel,
      builder: (context, _) {
        return Scaffold(
          appBar: _viewModel.isFullscreen
              ? null
              : AppBar(
                  titleSpacing: 0,
                  title: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _viewModel.pageTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        _viewModel.currentUrl,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 11,
                          color: Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withValues(alpha: 0.65),
                        ),
                      ),
                    ],
                  ),
                  actions: [
                    IconButton(
                      tooltip: _viewModel.isDesktopMode
                          ? 'Đang ở chế độ Desktop (chạm để đổi Mobile)'
                          : 'Đang ở chế độ Mobile (chạm để đổi Desktop)',
                      icon: Icon(
                        _viewModel.isDesktopMode
                            ? Icons.desktop_mac_rounded
                            : Icons.phone_iphone_rounded,
                      ),
                      onPressed: _toggleDesktopMode,
                    ),
                    IconButton(
                      tooltip: 'Tải lại',
                      icon: const Icon(Icons.refresh_rounded),
                      onPressed: _webViewController.reload,
                    ),
                    IconButton(
                      tooltip: 'Toàn màn hình',
                      icon: const Icon(Icons.fullscreen_rounded),
                      onPressed: _viewModel.toggleFullscreen,
                    ),
                    PopupMenuButton<String>(
                      onSelected: (value) async {
                        switch (value) {
                          case 'back':
                            if (_viewModel.canGoBack) {
                              await _webViewController.goBack();
                            }
                          case 'forward':
                            if (_viewModel.canGoForward) {
                              await _webViewController.goForward();
                            }
                          case 'copy':
                            await _copyCurrentUrl();
                          case 'safari':
                            await _openInExternalBrowser();
                        }
                      },
                      itemBuilder: (context) => [
                        PopupMenuItem<String>(
                          value: 'back',
                          enabled: _viewModel.canGoBack,
                          child: const ListTile(
                            leading: Icon(Icons.arrow_back_rounded),
                            title: Text('Quay lại trang trước'),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                        PopupMenuItem<String>(
                          value: 'forward',
                          enabled: _viewModel.canGoForward,
                          child: const ListTile(
                            leading: Icon(Icons.arrow_forward_rounded),
                            title: Text('Đi tiếp'),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                        const PopupMenuDivider(),
                        const PopupMenuItem<String>(
                          value: 'copy',
                          child: ListTile(
                            leading: Icon(Icons.copy_rounded),
                            title: Text('Sao chép link'),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                        const PopupMenuItem<String>(
                          value: 'safari',
                          child: ListTile(
                            leading: Icon(Icons.open_in_browser_rounded),
                            title: Text('Mở bằng Safari'),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
          body: SafeArea(
            top: _viewModel.isFullscreen,
            bottom: false,
            child: Stack(
              children: [
                WebViewWidget(controller: _webViewController),
                if (_viewModel.isLoading)
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: LinearProgressIndicator(
                      value: _viewModel.loadingProgress / 100.0,
                      minHeight: 3,
                    ),
                  ),
                if (_viewModel.loadError != null)
                  _ErrorOverlay(
                    message: _viewModel.loadError!,
                    onRetry: () {
                      _viewModel.setLoadError(null);
                      _webViewController.reload();
                    },
                    onOpenSafari: _openInExternalBrowser,
                  ),
                if (_viewModel.isFullscreen)
                  Positioned(
                    right: 14,
                    bottom: 24,
                    child: FloatingActionButton.small(
                      heroTag: 'exit_fullscreen',
                      tooltip: 'Hiện thanh công cụ',
                      onPressed: _viewModel.toggleFullscreen,
                      child: const Icon(Icons.fullscreen_exit_rounded),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ErrorOverlay extends StatelessWidget {
  const _ErrorOverlay({
    required this.message,
    required this.onRetry,
    required this.onOpenSafari,
  });

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onOpenSafari;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      padding: const EdgeInsets.all(24),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.wifi_off_rounded,
              size: 56,
              color: Theme.of(context).colorScheme.error,
            ),
            const SizedBox(height: 16),
            const Text(
              'Không thể tải phiên Remote Control',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Theme.of(context)
                    .colorScheme
                    .onSurface
                    .withValues(alpha: 0.7),
              ),
            ),
            const SizedBox(height: 24),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              alignment: WrapAlignment.center,
              children: [
                FilledButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Thử lại'),
                ),
                OutlinedButton.icon(
                  onPressed: onOpenSafari,
                  icon: const Icon(Icons.open_in_browser_rounded),
                  label: const Text('Mở trong Safari'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/foundation.dart';

import '../../../../data/repositories/session_repository.dart';
import '../../../../domain/models/remote_session.dart';

/// ViewModel managing the active Antigravity Remote Control WebView session.
class RemoteWorkspaceViewModel extends ChangeNotifier {
  RemoteWorkspaceViewModel({
    required RemoteSession session,
    required SessionRepository sessionRepository,
  })  : _session = session,
        _sessionRepository = sessionRepository,
        _currentUrl = session.url,
        _pageTitle = session.name,
        _isDesktopMode = session.preferDesktopMode;

  final SessionRepository _sessionRepository;
  RemoteSession _session;

  RemoteSession get session => _session;

  String _currentUrl;
  String get currentUrl => _currentUrl;

  String _pageTitle;
  String get pageTitle => _pageTitle;

  int _loadingProgress = 0;
  int get loadingProgress => _loadingProgress;

  bool get isLoading => _loadingProgress < 100;

  bool _canGoBack = false;
  bool get canGoBack => _canGoBack;

  bool _canGoForward = false;
  bool get canGoForward => _canGoForward;

  bool _isDesktopMode;
  bool get isDesktopMode => _isDesktopMode;

  bool _isFullscreen = false;
  bool get isFullscreen => _isFullscreen;

  String? _loadError;
  String? get loadError => _loadError;

  static const String desktopUserAgent =
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
      'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Safari/605.1.15';

  static const String mobileUserAgent =
      'Mozilla/5.0 (iPhone; CPU iPhone OS 17_6 like Mac OS X) '
      'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.6 Mobile/15E148 Safari/604.1';

  String get activeUserAgent =>
      _isDesktopMode ? desktopUserAgent : mobileUserAgent;

  void updateProgress(int progress) {
    _loadingProgress = progress.clamp(0, 100);
    if (progress > 0 && _loadError != null) {
      _loadError = null;
    }
    notifyListeners();
  }

  void updateNavigationState({
    String? url,
    String? title,
    bool? canGoBack,
    bool? canGoForward,
  }) {
    if (url != null && url.isNotEmpty) {
      _currentUrl = url;
    }
    if (title != null && title.trim().isNotEmpty) {
      _pageTitle = title.trim();
    }
    if (canGoBack != null) {
      _canGoBack = canGoBack;
    }
    if (canGoForward != null) {
      _canGoForward = canGoForward;
    }
    notifyListeners();
  }

  void setLoadError(String? message) {
    _loadError = message;
    notifyListeners();
  }

  Future<void> toggleDesktopMode() async {
    _isDesktopMode = !_isDesktopMode;
    _session = _session.copyWith(preferDesktopMode: _isDesktopMode);
    notifyListeners();
    await _sessionRepository.updateDesktopMode(_session.id, _isDesktopMode);
  }

  void toggleFullscreen() {
    _isFullscreen = !_isFullscreen;
    notifyListeners();
  }
}

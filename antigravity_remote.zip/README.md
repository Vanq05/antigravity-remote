# Antigravity Remote (iOS `.ipa`)

Ứng dụng iOS cho **Antigravity Remote Control**, hỗ trợ:
- **Quét mã QR Remote Control** trực tiếp bằng camera (có bật/tắt đèn flash và đổi camera).
- **Nhập / dán link Remote Control** thủ công (hỗ trợ cả `https://antigravity.google/...`, link tunnel và địa chỉ mạng LAN).
- **Chế độ Desktop đầy đủ (mặc định)** và chuyển đổi linh hoạt sang chế độ Mobile, kèm thanh công cụ ẩn/hiện toàn màn hình, tải lại, sao chép link, hoặc mở bằng Safari.
- **Lưu & quản lý nhiều phiên**: Ghim phiên quan trọng, đổi tên, xóa và kết nối lại chỉ với 1 chạm.

---

## Cách xuất file `AntigravityRemote.ipa` miễn phí (không cần máy Mac hay cài Flutter)

### Bước 1: Đẩy thư mục này lên GitHub
1. Truy cập [github.com](https://github.com) và tạo một repository mới (ví dụ: `antigravity-remote`, để **Public** để build macOS miễn phí không giới hạn).
2. Tải toàn bộ file trong thư mục `antigravity_remote` lên repo đó (có thể dùng **Add file → Upload files** ngay trên web GitHub, nhớ kéo thả cả thư mục `.github`).

### Bước 2: Tải file `.ipa` từ GitHub Actions
1. Vào tab **Actions** trên repository GitHub của bạn.
2. Chọn workflow **Build iOS IPA (Antigravity Remote)** (nếu chưa tự chạy, bấm **Run workflow**).
3. Chờ khoảng 4–6 phút để máy chủ macOS của GitHub tự động build và đóng gói.
4. Khi hoàn tất (dấu tích xanh), cuộn xuống mục **Artifacts** và bấm tải **AntigravityRemote-ipa** → giải nén sẽ có file `AntigravityRemote.ipa`.

### Bước 3: Cài `AntigravityRemote.ipa` lên iPhone
Vì đây là file `.ipa` chưa ký (unsigned), bạn cài lên iPhone bằng một trong các công cụ miễn phí:
- **Sideloadly** (trên Windows — chỉ cần cắm cáp iPhone và kéo thả file `.ipa`).
- **AltStore** hoặc **SideStore**.
- **TrollStore** (nếu máy hỗ trợ).

---

## Cách sử dụng
1. Trên máy tính đang chạy **Antigravity Desktop**, bật **Remote Control** (`Ctrl+Shift+R`) để lấy mã QR hoặc link.
2. Mở app **Antigravity Remote** trên iPhone → bấm **Quét mã QR Remote Control** (hoặc dán link) → đăng nhập tài khoản Google của bạn và sử dụng đầy đủ giao diện như trên máy tính.
